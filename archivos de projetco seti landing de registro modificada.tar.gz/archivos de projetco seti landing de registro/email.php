<?php

    $to      = 'comercial@seticonsulting.com';
    $subject = 'Contacto desde pagina web, SEGURIDAD INFORMATICA';
    $headers = 
        'From: ' . $_POST['email'] . "\r\n" .
        'Reply-To: ' . $_POST['email'] . "\r\n" .
        'X-Mailer: PHP/' . phpversion();

    try {

        $email = $_POST['email'];
        $name = $_POST['name'];

        $finalMessage = "
            Correo: ${email}\r\n
            Nombre: ${name}
        ";

    } catch(Exception $excepcion) {

        $response = json_encode(['status' => 500, 'message' => 'Error al crear mensaje']);
        echo($response);
        die();

    }

    try {
        mail($to, $subject, $finalMessage, $headers);
    } catch(Exception $excepcion) {

        $response = json_encode(['status' => 500, 'message' => 'Error al enviar mensaje']);
        echo($response);
        die();

    }

    // Se envia mensaje de confirmacion

    try {
        $headersSend = 
        'From: ' . $to . "\r\n" .
        'Reply-To: ' . $to . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
        $message = "Gracias ${name} por registrarte al programa de seguridad en una base de datos Oracle, a la brevedad un ejecutivo  de cuenta se pondra en contacto.";

        mail($_POST['email'], 'Programa de seguridad en Bases de Datos Oracle - SETIconsulting', $message, $headersSend);
    } catch(Exception $excepcion) {

        $response = json_encode(['status' => 500, 'message' => 'Error al enviar mensaje']);
        echo($response);
        die();

    }


    $response = json_encode(['status' => 200, 'message' => 'Mensaje enviado exitosamente']);
    echo($response);

    die(); 

?> 