$(document).ready(() => {

    $('#email-form3-2h').unbind()
    $('#email-form3-2h-name').unbind()

    $('#seguridad_informatica_suscribir').on('click', (event) => {
        let email = $('#email-form3-2h').val()
        let name = $('#email-form3-2h-name').val()

        let formData = new FormData()

        formData.append('email', email)
        formData.append('name', name)

        fetch('email.php', {
            method: 'POST',
            body: formData
        }).then((data) => {
            return data.json()
        }).then((data) => {
            if (data.status == 200) {
                console.log(data)
                document.querySelector("#thanks").removeAttribute('hidden')
                $('#thanks').val('Gracias por tu registro te hemos enviado un mensaje a tu correo electrónico')
            } else {
                alert('Intenta contactarnos por mensaje a: comercial@seticonsulting.com')
            }
        }).catch(() => {
            alert('Intenta contactarnos por mensaje a: comercial@seticonsulting.com')
        })
        event.preventDefault()
    })
})